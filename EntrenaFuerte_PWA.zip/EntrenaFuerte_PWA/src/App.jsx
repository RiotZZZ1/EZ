
import React, { useEffect, useMemo, useState } from "react";
function create12WeekRoutine(){ const weeks=[]; for(let w=1;w<=12;w++){ weeks.push({id:w,title:`Semana ${w}`,phase:w<=4?"Adaptación":w<=8?"Volumen":"Intensidad",days:[1,2,3,4].map(d=>({id:d,title:d===1?"Pecho + Tríceps + Abdomen":d===2?"Espalda + Bíceps + Core":d===3?"Hombros + Abdomen":"Pierna + Glúteo + Abdomen",exercises:[] })),miniReto:w===1?"Plancha acumulada: 3 minutos":w===2?"200 abdominales semanales":w===3?"500 sentadillas acumuladas":w===4?"Plancha lateral 2 min por lado":w<=8?"Añade 1 serie a los básicos":"Mantén fuerza + cardio moderado 2x/semana"})} return weeks;}
function useLocalStorage(key, initial){ const [state,setState]=useState(()=>{ try{const raw=localStorage.getItem(key); return raw?JSON.parse(raw):initial;}catch(e){return initial;} }); useEffect(()=>{ try{localStorage.setItem(key,JSON.stringify(state));}catch(e){} },[key,state]); return [state,setState];}
export default function App(){
  const routine = useMemo(()=>create12WeekRoutine(),[]);
  const [weekIndex,setWeekIndex] = useLocalStorage("ef_week",0);
  const [dayIndex,setDayIndex] = useLocalStorage("ef_day",0);
  const [checked,setChecked] = useLocalStorage("ef_checked", {});
  const [water,setWater] = useLocalStorage("ef_water",0);
  const [weightHistory,setWeightHistory] = useLocalStorage("ef_weight", [{ date: new Date().toISOString().slice(0,10), weight: 70 }]);
  const [view,setView] = useLocalStorage("ef_view","home");
  const [modalExercise,setModalExercise] = useState(null);

  // lightweight example exercises inserted for demo (short descriptions)
  useEffect(()=>{
    // populate exercises once
    const exSample = [
      {id:"press1",name:"Press de banca con mancuernas",sets:"4x8-10",desc:{muscles:"Pecho, tríceps",steps:["Acuéstate en banco.","Empuja hasta extender."],tips:["Inhala al bajar"],avoid:["No rebotar"]}},
      {id:"remo1",name:"Remo con mancuernas 1 brazo",sets:"4x10",desc:{muscles:"Espalda",steps:["Inclina torso 45°","Jala al abdomen"],tips:["Aprieta escápulas"],avoid:[]}},
      {id:"sent1",name:"Sentadillas con mancuernas",sets:"4x10-12",desc:{muscles:"Piernas",steps:["Pies ancho hombros","Baja hasta 90°"],tips:["Empuja con talones"],avoid:[]}}
    ];
    try{
      const weeks = [...routine];
      weeks.forEach(w=>{
        w.days.forEach(d=>{
          if(d.exercises.length===0){
            d.exercises.push(...exSample.map(e=>({...e,id:e.id+"-"+w.id+"-"+d.id})));
          }
        });
      });
      // override routine variable (mutable)
      // we can't replace useMemo easily; instead store to window for demo
      window._ef_routine = weeks;
    }catch(e){}
  },[]);

  const currentWeek = (window._ef_routine || routine)[weekIndex];
  const currentDay = currentWeek.days[dayIndex];

  const toggleExercise = (id)=> setChecked(s=>({...s,[id]:!s[id]}));
  const addWater=(ml)=> setWater(w=>Math.min(5000,w+ml));
  const resetWeek = ()=> { const newChecked={...checked}; currentWeek.days.forEach(d=>d.exercises.forEach(e=>delete newChecked[e.id])); setChecked(newChecked); }

  return (
    <div className="app-container">
      <header style={{marginBottom:12}}>
        <h1 style={{fontSize:24,fontWeight:700}}>Entrena Fuerte</h1>
        <div className="small-muted">Semana {currentWeek.id} · {currentWeek.phase}</div>
      </header>

      {view==="home" && (
        <section className="card" style={{marginBottom:12}}>
          <h2 style={{fontWeight:700}}>{currentWeek.title}</h2>
          <div className="small-muted">{currentWeek.miniReto}</div>
          <div style={{display:"flex",gap:8,marginTop:12}}>
            <button className="button-accent" onClick={()=>setView("rutina")}>Ver rutina</button>
            <button className="button-accent" onClick={()=>setView("nutricion")}>Nutrición</button>
          </div>

          <div style={{display:"flex",gap:8,marginTop:12}}>
            <div className="card" style={{flex:1}}>
              <div className="small-muted">Agua</div>
              <div style={{fontWeight:700}}>{(water/1000).toFixed(2)} L / 3.00 L</div>
              <div style={{marginTop:8,display:"flex",gap:8}}>
                <button className="button-accent" onClick={()=>addWater(250)}>+250 ml</button>
                <button className="button-accent" onClick={()=>addWater(500)}>+500 ml</button>
              </div>
            </div>
            <div className="card" style={{flex:1}}>
              <div className="small-muted">Progreso</div>
              <div style={{fontWeight:700}}>{weightHistory[weightHistory.length-1].weight} kg</div>
            </div>
          </div>
        </section>
      )}

      {view==="rutina" && (
        <section>
          <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:8}}>
            <h2 style={{fontSize:18,fontWeight:700}}>{currentWeek.title} — {currentDay.title}</h2>
            <div className="small-muted">{currentWeek.phase}</div>
          </div>
          <div style={{display:"grid",gap:8}}>
            {currentDay.exercises.map(ex=>(
              <div key={ex.id} className="card" style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
                <div>
                  <div style={{fontWeight:700}}>{ex.name}</div>
                  <div className="small-muted">{ex.sets}</div>
                </div>
                <div style={{display:"flex",alignItems:"center",gap:8}}>
                  <button onClick={()=>setModalExercise(ex)} className="small-muted">Detalles</button>
                  <input type="checkbox" checked={!!checked[ex.id]} onChange={()=>toggleExercise(ex.id)} />
                </div>
              </div>
            ))}
          </div>
          <div style={{display:"flex",gap:8,marginTop:12}}>
            <button className="button-accent" onClick={()=>resetWeek()}>Reiniciar semana</button>
            <button className="button-accent" onClick={()=>{ setWeekIndex(w=>Math.min(11,w+1)); setDayIndex(0); setView('home'); }}>Siguiente semana</button>
          </div>
        </section>
      )}

      {view==="nutricion" && (
        <section className="card">
          <h2 style={{fontWeight:700}}>Nutrición — Guía para ectomorfo</h2>
          <div className="small-muted" style={{marginTop:8}}>Antes: plátano + café. Después: batido proteína + avena.</div>
          <ul style={{marginTop:8}}>
            <li className="small-muted">Yogur griego con frutos secos</li>
            <li className="small-muted">Huevos + pan integral</li>
            <li className="small-muted">Salmón / pollo / arroz integral</li>
          </ul>
        </section>
      )}

      {view==="progreso" && (
        <section className="card">
          <h2 style={{fontWeight:700}}>Progreso</h2>
          <div className="small-muted">Peso actual: {weightHistory[weightHistory.length-1].weight} kg</div>
          <div style={{marginTop:8}}><small className="small-muted">Añadir medida:</small></div>
          <div style={{display:"flex",gap:8,marginTop:8}}>
            <input id="winput" className="card" placeholder="kg" />
            <button className="button-accent" onClick={()=>{
              const el=document.getElementById('winput'); if(!el) return; const val=parseFloat(el.value); if(isNaN(val)) return; setWeightHistory(h=>[...h,{date:new Date().toISOString().slice(0,10),weight:val}]); el.value='';}}>Añadir</button>
          </div>
        </section>
      )}

      {view==="perfil" && (
        <section className="card">
          <h2 style={{fontWeight:700}}>Perfil & Ajustes</h2>
          <div className="small-muted" style={{marginTop:8}}>Tema: Oscuro (por defecto)</div>
          <div style={{marginTop:8}}><button className="button-accent" onClick={()=>{localStorage.clear();window.location.reload();}}>Borrar datos</button></div>
        </section>
      )}

      <nav className="bottom-nav card" style={{display:"flex",gap:8,justifyContent:"space-between",alignItems:"center"}}>
        <button onClick={()=>setView('home')} className="small-muted">Inicio</button>
        <button onClick={()=>setView('rutina')} className="small-muted">Rutina</button>
        <button onClick={()=>setView('nutricion')} className="small-muted">Nutrición</button>
        <button onClick={()=>setView('progreso')} className="small-muted">Progreso</button>
        <button onClick={()=>setView('perfil')} className="small-muted">Perfil</button>
      </nav>

      {modalExercise && (
        <div style={{position:'fixed',inset:0,background:'rgba(0,0,0,0.6)',display:'flex',alignItems:'center',justifyContent:'center',padding:16}}>
          <div style={{background:'#111',padding:16,borderRadius:12,maxWidth:520,width:'100%'}}>
            <div style={{display:'flex',justifyContent:'space-between',alignItems:'start'}}>
              <div>
                <h3 style={{fontWeight:700}}>{modalExercise.name}</h3>
                <div className="small-muted">{modalExercise.sets}</div>
              </div>
              <button className="small-muted" onClick={()=>setModalExercise(null)}>Cerrar</button>
            </div>
            <div style={{marginTop:12,color:'#cbd5e1'}}>
              {modalExercise.desc.muscles && <div><strong>Músculos:</strong> {modalExercise.desc.muscles}</div>}
              {modalExercise.desc.steps && <div><strong>Técnica:</strong><ol>{modalExercise.desc.steps.map((s,i)=>(<li key={i}>{s}</li>))}</ol></div>}
              {modalExercise.desc.tips && <div><strong>Consejos:</strong><ul>{modalExercise.desc.tips.map((t,i)=>(<li key={i}>{t}</li>))}</ul></div>}
              {modalExercise.desc.avoid && <div><strong>Errores:</strong><ul style={{color:'#fca5a5'}}>{modalExercise.desc.avoid.map((t,i)=>(<li key={i}>{t}</li>))}</ul></div>}
            </div>
            <div style={{display:'flex',justifyContent:'flex-end',marginTop:12}}>
              <button className="button-accent" onClick={()=>{ setChecked(s=>({...s,[modalExercise.id]:true})); setModalExercise(null);}}>Marcar completado</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
